#!/bin/bash

# Find and replace all occurrances of '' and fix rest of line.

for file in $(find); do
    if [[ -f $file ]]; then
        [[ $(cat $file | grep m32) ]]
        if [[ $? == 0 ]]; then
            echo writing...
            echo $file
           sed 's/\//g' $file > tmp && mv tmp $file
       fi
    fi
done