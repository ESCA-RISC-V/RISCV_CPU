// Copyright 2017 ETH Zurich and University of Bologna.
// Copyright and related rights are licensed under the Solderpad Hardware
// License, Version 0.51 (the “License”); you may not use this file except in
// compliance with the License.  You may obtain a copy of the License at
// http://solderpad.org/licenses/SHL-0.51. Unless required by applicable law
// or agreed to in writing, software, hardware and materials distributed under
// this License is distributed on an “AS IS” BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

#include "uart.h"
#include "utils.h"
#include "uart.h"
#include "pulpino.h"
/**
 * Setup UART. The UART defaults to 8 bit character mode with 1 stop bit.
 *
 * parity       Enable/disable parity mode
 * clk_counter  Clock counter value that is used to derive the UART clock.
 *              It has to be in the range of 1..2^16.
 *              There is a prescaler in place that already divides the SoC
 *              clock by 16.  Since this is a counter, a value of 1 means that
 *              the SoC clock divided by 16*2 = 32 is used. A value of 31 would mean
 *              that we use the SoC clock divided by 16*32 = 512.
 */
void uart_set_cfg(int parity, uint16_t clk_counter) {
  *(volatile unsigned int*)(0x1a109004) = 0x04000000;                                   // gy : set soc interrupt up
  *(volatile unsigned int*)(0x1a106004) = 0xFFFFFFFD;                                   // gy : set uart tx event up
  *(volatile unsigned int*)(UART_BASE_ADDR-0x80) = 1;                                     // gy : set uart clock gating configuration
  *(volatile unsigned int*)(UART_REG_SET) = 0x560306;                                     // gy : set uart configuration - frequency, etc

}

void uart_send(const char* str, unsigned int len) {
  unsigned int i;

  while(len > 0) {
    // process this in batches of 16 bytes to actually use the FIFO in the UART

    // wait until there is space in the fifo
    while( (*(volatile unsigned int*)(UART_REG_LSR) & 0x20) == 0);

    for(i = 0; (i < UART_FIFO_DEPTH) && (len > 0); i++) {
      // load FIFO
      *(volatile unsigned int*)(UART_REG_THR) = *str++;

      len--;
    }
  }
}

char uart_getchar() {
  while((*((volatile int*)UART_REG_LSR) & 0x1) != 0x1);

  return *(volatile int*)UART_REG_RBR;
}


volatile char charbuffer;                                                                 // gy : add a char - to use as buffer
void uart_sendchar(const char c) {
  // wait until there is space in the fifo
  //while( (*(volatile unsigned int*)(UART_REG_STA) & 0x1) == 1){asm volatile ("wfi");}   // gy : wait until uart_status = 0
  while( *(volatile unsigned int*)(UART_REG_TSI) != 0)asm volatile ("nop");               // gy : wait until uart_status = 0
  
  charbuffer = c;                                                                         // gy : save the char at buffer

  *(volatile unsigned int*)(UART_REG_TSA) = (unsigned int)&charbuffer;                    // gy : load the startaddr = bufferaddr
  *(volatile unsigned int*)(UART_REG_TSI) = 1;                                            // gy : load the size = 1 (because char)
  *(volatile unsigned int*)(UART_REG_TCF) = 0x10;                                         // gy : start the uart
  
  return;
}

void uart_wait_tx_done(void) {
  // wait until there is space in the fifo
  while( (*(volatile unsigned int*)(UART_REG_LSR) & 0x40) == 0);
}
