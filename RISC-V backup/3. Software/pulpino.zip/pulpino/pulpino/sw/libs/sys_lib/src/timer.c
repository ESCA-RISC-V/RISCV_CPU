// Copyright 2017 ETH Zurich and University of Bologna.
// Copyright and related rights are licensed under the Solderpad Hardware
// License, Version 0.51 (the “License”); you may not use this file except in
// compliance with the License.  You may obtain a copy of the License at
// http://solderpad.org/licenses/SHL-0.51. Unless required by applicable law
// or agreed to in writing, software, hardware and materials distributed under
// this License is distributed on an “AS IS” BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

#include "timer.h"

void reset_timer(void) {
  TRSLO = 0x1;    				// gy : modified
}

void start_timer(void) {
  TSTLO = 0x1; 					// gy : modified
}

void stop_timer(void) {
  TPRLO &= 0xFFFFFFFE; 			// gy : modified
}

unsigned int get_time(void) {
  return TIRLO;
}

void init_timer_hi(void){
	//MASK_SET = 0x800;			// gy : enable timer high interrupt
	TRSHI = 1;
	TOCRHI = 0xFFFFFFFF;
	TPRHI = 0x20D1;				// gy : 32kHz, prescaler = 32, prescaler enable, auto-restart mode, start
}

unsigned int get_ms(void){
	return TIRHI;
}

void init_timer_hi_us(void) {
	TRSHI = 1;
	TOCRHI =  0xFFFFFFFF;
	TPRHI = 0x91;
}

unsigned int get_time_us(void) {
	return (unsigned int)(TIRHI*(1000000/32000));
}
