// Copyright 2017 ETH Zurich and University of Bologna.
// Copyright and related rights are licensed under the Solderpad Hardware
// License, Version 0.51 (the “License”); you may not use this file except in
// compliance with the License.  You may obtain a copy of the License at
// http://solderpad.org/licenses/SHL-0.51. Unless required by applicable law
// or agreed to in writing, software, hardware and materials distributed under
// this License is distributed on an “AS IS” BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

/**
 * @file
 * @brief Timer library.
 *
 * Provides Timer function like writing the appropriate
 * timer registers and uttility functions to cycle count
 * certain events. Used in bench.h.
 *
 * @author Florian Zaruba
 *
 * @version 1.0
 *
 * @date 2/10/2015
 *
 */
#ifndef __TIMER_H__
#define __TIMER_H__

#include "pulpino.h"

#define TIMER_LO_ADDR         0x08  					  	// modified
#define TIMER_LO_CNFG         0x00 						// added
#define TIMER_LO_CMPR  		0x10 						// added
#define TIMER_LO_STRT			0x18 						// added
#define TIMER_LO_REST			0x20						// added

#define TIMER_HI_ADDR         0x0c 						// modified
#define TIMER_HI_CNFG         0x04 						// added
#define TIMER_HI_CMPR		    0x14 						// added
#define TIMER_HI_STRT			0x1C 						// added
#define TIMER_HI_REST			0x24						// added

/* pointer to mem of timer unit - PointerTimer */
#define __PT__(a) *(volatile int*) (TIMER_BASE_ADDR + a)

/** timer low register - contains the actual cycle counter */
#define TIRLO __PT__(TIMER_LO_ADDR)

/** timer low control register */
#define TPRLO __PT__(TIMER_LO_CNFG)

/** timer low output compare register */
#define TOCRLO __PT__(TIMER_LO_CMPR)

#define TSTLO __PT__(TIMER_LO_STRT) // added - timer low start timer

#define TRSLO __PT__(TIMER_LO_REST) // added - timer low reset timer

/** timer low register - contains the actual cycle counter */
#define TIRHI __PT__(TIMER_HI_ADDR)

/** timer low control register */
#define TPRHI __PT__(TIMER_HI_CNFG)

/** timer low output compare register */
#define TOCRHI __PT__(TIMER_HI_CMPR)

#define TSTHI __PT__(TIMER_HI_STRT) // added - timer high start timer

#define TRSHI __PT__(TIMER_HI_REST) // added - timer high reset timer

int microsec;

void reset_timer(void);

void start_timer(void);

void stop_timer(void);

unsigned int get_time(void);

void init_timer_hi(void);

unsigned int get_ms(void);

void init_timer_hi_us(void);
unsigned int get_time_us(void);

#endif
