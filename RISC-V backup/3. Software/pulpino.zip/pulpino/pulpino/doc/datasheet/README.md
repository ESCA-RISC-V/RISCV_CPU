# PDF version

A precompiled version of this data sheet is available on our [website](http://www.pulp-platform.org/documentation/)

Direct link: [PULPino Data Sheet](http://www.pulp-platform.org/wp-content/uploads/2016/02/pulpino_datasheet.pdf)

# Compile Steps

If you want to build the documentation from source, you can use `make all` to
compile the LaTeX sources. This also takes care of preparing some of the
figures that are generated on-demand.
