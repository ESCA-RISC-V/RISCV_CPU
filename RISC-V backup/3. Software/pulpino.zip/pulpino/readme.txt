2021.05.16
ESCA
Kwon Guyun (1216kg@naver.com)

Prerequisite

	Ubuntu20.04

	pulp-riscv-gnu-toolchain 
		should be configured with --with-arch=rv32i (no rv32imc - this make some compressed extension)
		your PATH must include [TOOLCHAIN_PATH]/bin


	cmake

	python2
		sudo apt-get install python2
		sudo ln -s /usr/bin/python2 /usr/bin/python

How to compile freertos

	1. open pulpino/sw/build/tmp.sh change [PATH_TO_PULPINO] to path to pulpino
	2. go to pulpino/sw/build folder and run tmp.sh
		./tmp.sh
	3. go to pulpino/sw folder and run tmp2.sh
		./tmp2.sh
	4. go to pulpino/sw/build folder and run ./cmake_configure.riscv.gcc.sh
	5. you must see a error. do not panic
	6. go to pulpino/sw/build folder and run tmp.sh again
		./tmp.sh
	7. go to pulpino/sw/build folder and run ./cmake_configure.riscv.gcc.sh
	8. go to pulpino/sw/build folder and type make freertos
	9. go to pulpino/sw/build/apps/freertos folder, there should be freertos.elf file

P.S.
	
	you can modify freertos functions at files under pulpino/sw/apps/freertos
	you can modify interrupt vector or other assembly code at pulpino/sw/ref/crt0.riscv.S
	you can modify library functions at files under pulpino/sw/libs/
